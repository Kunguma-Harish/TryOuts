//
//  SkiaBridge.h
//  Skia Integration
//
//  Created by Subramanian on 05/03/25.
//

#ifndef SkiaBridge_h
#define SkiaBridge_h

#include "CppSkiaMetalRenderer/CppSkiaMetalRenderer.hpp"
#include "include/core/SkCanvas.h"

#import <UIKit/UIKit.h>
#import <MetalKit/MetalKit.h>


@interface SkiaRenderer : NSObject
- (UIImage *)drawSomethinxg;
@end

@interface SkiaMetalRenderer : NSObject

- (instancetype)initWithDevice:(id<MTLDevice>)device :(id<MTLCommandQueue>)queue;
- (void)drawInMTKView:(MTKView *)view;

@end

@interface CustomMetalView : MTKView

@property (nonatomic, assign) BOOL isDirty;
@property (nonatomic, assign) BOOL colorToggle;

- (void)readyToDraw;
- (void)drawSucess;
- (void)toggle;

- (CGColorRef)getRedColor;
- (CGColorRef)getGreenColor;
- (CGColorRef)getBlueColor;

@end
#endif /* SkiaBridge_h */
