//
//  CppSkiaMetalRenderer.cpp
//  Skia Integration
//
//  Created by kunguma-14252 on 01/04/25.
//

#include "CppSkiaMetalRenderer.hpp"

#import "include/gpu/ganesh/GrDirectContext.h"
#import "include/gpu/ganesh/mtl/GrMtlBackendContext.h"
#import "include/gpu/ganesh/mtl/GrMtlTypes.h"
#import "include/gpu/ganesh/mtl/GrMtlDirectContext.h"
#import "include/gpu/ganesh/mtl/GrMtlBackendSurface.h"
#import "include/gpu/ganesh/GrBackendSurface.h"
#import "include/gpu/ganesh/SkSurfaceGanesh.h"
#import "include/core/SkSurface.h"
#include "include/ports/SkCFObject.h"
#include "include/core/SkCanvas.h"
#include "include/core/SkPaint.h"
#include "include/core/SkColorSpace.h"

//added for drawing using SkPicture.
#include "include/core/SkPictureRecorder.h"
#include "include/core/SkPicture.h"
  
#include "include/core/SkColorType.h"
#include "include/gpu/ganesh/GrContextOptions.h"
#include "include/gpu/ganesh/mtl/GrMtlTypes.h"
#include "include/gpu/ganesh/mtl/SkSurfaceMetal.h"
#include "include/effects/SkGradientShader.h"

CppSkiaMetalRenderer::CppSkiaMetalRenderer(id<MTLDevice> device, id<MTLCommandQueue> queue) : device(device), queue(queue) {
    this->backendContext.fDevice = sk_cfp<CFTypeRef>{(void*)CFBridgingRetain(device)};
    this->backendContext.fQueue  = sk_cfp<CFTypeRef>{(void*)CFBridgingRetain(queue)};
    this->_skiaContextHolder = GrDirectContexts::MakeMetal(this->backendContext);
    printf("kungu cpp: init called... \n");
    printf(".... \n");
};

void CppSkiaMetalRenderer::drawInMTKView(MTKView *view) {
    auto skiaContext = this->_skiaContextHolder.get();
    if (!skiaContext || !view) {
        return;
    };
    printf("kungu cpp: draw called... \n");
    printf(".... \n");
};
