//
//  SkiaMetalRenderer.m
//  Skia Integration
//
//  Created by Subramanian on 05/03/25.
//

#import "SkiaBridge.h"
#import "include/gpu/ganesh/GrDirectContext.h"
#import "include/gpu/ganesh/mtl/GrMtlBackendContext.h"
#import "include/gpu/ganesh/mtl/GrMtlTypes.h"
#import "include/gpu/ganesh/mtl/GrMtlDirectContext.h"
#import "include/gpu/ganesh/mtl/GrMtlBackendSurface.h"
#import "include/gpu/ganesh/GrBackendSurface.h"
#import "include/gpu/ganesh/SkSurfaceGanesh.h"
#import "include/core/SkSurface.h"
#include "include/ports/SkCFObject.h"
#include "include/core/SkCanvas.h"
#include "include/core/SkPaint.h"
#include "include/core/SkColorSpace.h"

#include "include/core/SkPictureRecorder.h"
#include "include/core/SkPicture.h"
//#include "include/core/SkRefCnt.h"
  
#include "include/core/SkColorType.h"
#include "include/gpu/ganesh/GrContextOptions.h"
#include "include/gpu/ganesh/mtl/GrMtlTypes.h"
#include "include/gpu/ganesh/mtl/SkSurfaceMetal.h"
#include "include/effects/SkGradientShader.h"

#include <stdlib.h>

static float randomFloat() {
    return static_cast<float>(arc4random()) / UINT32_MAX;
}

// Function to generate a random SkColor4f
static SkColor4f randomSkColor4f() {
    float red = randomFloat();
    float green = randomFloat();
    float blue = randomFloat();
    float alpha = randomFloat();

    return SkColor4f{red, green, blue, alpha};
}

static void config_paint(SkPaint* paint) {
//    if (!paint->getShader()) {
        const SkColor4f colors[2] = {randomSkColor4f(), randomSkColor4f()};
        const SkPoint points[2] = {{0, -1024}, {0, 1024}};
    paint->setShader(SkGradientShader::MakeLinear(points, colors, nullptr, nullptr, 2, SkTileMode::kClamp, 0, nullptr));
//    }
}

static void draw_example(SkSurface* surface, const SkPaint& paint, double rotation, const std::vector<CGColorRef>& colors) {
    SkCanvas* canvas = surface->getCanvas();
    canvas->save();
    canvas->translate(surface->width() * 0.5f, surface->height() * 0.5f);
    canvas->rotate(rotation);
    canvas->drawPaint(paint);
    canvas->restore();
    
    int radius = 10;
    for (int i = 0; i < surface->width(); i += radius * 2) {
        for (int j = 0; j < surface->height(); j += radius * 2) {
            SkPaint paint;
            if (colors.size() > 0) {
                int randomIndex = arc4random_uniform(3);
                CGColorRef colorRef = colors.at(randomIndex);
                
                const CGFloat *components = CGColorGetComponents(colorRef);
                size_t componentCount = CGColorGetNumberOfComponents(colorRef);
                CGFloat red = components[0];
                CGFloat green = components[1];
                CGFloat blue = components[2];
                CGFloat alpha = (componentCount == 4) ? components[3] : 1.0;

                SkColor skColor = SkColorSetARGB((int)(alpha * 255), (int)(red * 255), (int)(green * 255), (int)(blue * 255));
                paint.setColor(skColor);
                
            } else {
                paint = SkPaint(randomSkColor4f());
            }

            
            canvas->drawCircle(i, j, radius, paint);
        }
    }
}

static void draw_rect(SkSurface* surface, const SkPaint& paint, double rotation, const std::vector<CGColorRef>& colors, bool toggle) {
    SkCanvas* canvas = surface->getCanvas();
    
    SkPictureRecorder recorder;
    SkCanvas* recoderCanvas = recorder.beginRecording(surface->width(), surface->height());
    
    recoderCanvas->save();
    recoderCanvas->translate(surface->width() * 0.5f, surface->height() * 0.5f);
    recoderCanvas->rotate(rotation);
    recoderCanvas->restore();
    
    int height = 10;
    int x = 1;
    while (x > 0) {
        for (int i = 0; i < surface->width(); i += height) {
            for (int j = 0; j < surface->height(); j += height) {
                SkPaint rectPaint;
                if (colors.size() > 0) {
                    int _colorIndex = ((i / height) + (j / height)) % 2;
                    int colorIndex = toggle ? _colorIndex : _colorIndex == 0 ? 1 : 0;
                    CGColorRef colorRef = colors.at(colorIndex);
                    
                    const CGFloat *components = CGColorGetComponents(colorRef);
                    size_t componentCount = CGColorGetNumberOfComponents(colorRef);
                    CGFloat red = components[0];
                    CGFloat green = components[1];
                    CGFloat blue = components[2];
                    CGFloat alpha = (componentCount == 4) ? components[3]  : 1.0;
                    
                    SkColor skColor = SkColorSetARGB((int)(alpha * 255), (int)(red * 255), (int)(green * 255), (int)(blue * 255));
                    rectPaint.setColor(skColor);
                    
                } else {
                    rectPaint = SkPaint(randomSkColor4f());
                }
                
                recoderCanvas->drawRect(SkRect::MakeXYWH(i, j, height, height), rectPaint);
            }
        }
        x--;
    }
    const sk_sp<SkPicture> picture = recorder.finishRecordingAsPicture();
    canvas->drawPicture(picture);
}

static void convertSkPaintFromCGColor(CGColorRef colorRef, SkPaint* paint) {
    // Get the color components from the CGColorRef
    const CGFloat *components = CGColorGetComponents(colorRef);
    
    // Get the number of components
    size_t componentCount = CGColorGetNumberOfComponents(colorRef);
    
    // Assuming the color is in RGBA format
    CGFloat red = components[0];
    CGFloat green = components[1];
    CGFloat blue = components[2];
    CGFloat alpha = (componentCount == 4) ? components[3] : 1.0;
    

    SkColor skColor = SkColorSetARGB((int)(alpha * 255), (int)(red * 255), (int)(green * 255), (int)(blue * 255));
    paint->setColor(skColor);
}

@interface SkiaMetalRenderer ()
@property (strong) id<MTLDevice> metalDevice;
@property (strong) id<MTLCommandQueue> metalQueue;
@property(nonatomic, assign) GrDirectContext* skiaContext;
@end

@implementation SkiaMetalRenderer

static GrMtlBackendContext backendContext;
sk_sp<GrDirectContext> _skiaContextHolder;
SkPaint fPaint;
SkPaint cusPaint;
std::vector<CGColorRef> arrColor;
int count = 0;

- (instancetype)initWithDevice:(id<MTLDevice>)device :(id<MTLCommandQueue>)queue {
    self = [super init];
    if (self) {
        [self setMetalDevice: device];
        [self setMetalQueue: queue];        
        
        if (backendContext.fDevice == nullptr && backendContext.fQueue == nullptr) {
            backendContext.fDevice.reset((__bridge void*)device);
            backendContext.fQueue.reset((__bridge void*)queue);
        }
        _skiaContextHolder = GrDirectContexts::MakeMetal(backendContext);
    }
    return self;
}

- (void)drawInMTKView:(MTKView *)view {
    self.skiaContext = _skiaContextHolder.get();

    if (![self skiaContext] || !view) {
        return;
    }
    
    if ([view isKindOfClass:[CustomMetalView class]]) {
        CustomMetalView *cusMtlView = (CustomMetalView *)view;
        
//        if (!cusMtlView.isDirty) {
//            return;
//        }

        arrColor.push_back(cusMtlView.getRedColor);
        arrColor.push_back(cusMtlView.getGreenColor);
        arrColor.push_back(cusMtlView.getBlueColor);

        int randomIndex = arc4random_uniform(arrColor.size());
        convertSkPaintFromCGColor(arrColor.at(randomIndex), &cusPaint);
        count++;

        float rotation = 45;
        
        id<CAMetalDrawable> nextDrawable = [(CAMetalLayer*)view.layer nextDrawable];
        void* texture = (__bridge void*)(nextDrawable.texture);

        GrMtlTextureInfo textureInfo;
        textureInfo.fTexture.retain(texture);
        GrBackendRenderTarget backendRT = GrBackendRenderTargets::MakeMtl(nextDrawable.texture.width,
                                                                          nextDrawable.texture.height,
                                                                          textureInfo);

        sk_sp<SkSurface> surface = SkSurfaces::WrapBackendRenderTarget(self.skiaContext,
                                                                       backendRT,
                                                                       kTopLeft_GrSurfaceOrigin,
                                                                       kBGRA_8888_SkColorType,
                                                                       nullptr,
                                                                       nullptr);
//        draw_example(surface.get(), cusPaint, rotation, arrColor);
        draw_rect(surface.get(), cusPaint, rotation, arrColor, cusMtlView.colorToggle);
        cusMtlView.drawSucess;
        cusMtlView.toggle;
        
        surface = nullptr;
        self.skiaContext->flushAndSubmit();
        
        id<MTLCommandBuffer> commandBuffer = [[self metalQueue] commandBuffer];
        [commandBuffer presentDrawable:nextDrawable];
        [commandBuffer commit];
    } else {
        config_paint(&fPaint);
        count++;
        float rotation = 45;
        
        id<CAMetalDrawable> nextDrawable = [(CAMetalLayer*)view.layer nextDrawable];
        void* texture = (__bridge void*)(nextDrawable.texture);
        
        GrMtlTextureInfo textureInfo;
        textureInfo.fTexture.retain(texture);
        GrBackendRenderTarget backendRT = GrBackendRenderTargets::MakeMtl(nextDrawable.texture.width,
                                                                          nextDrawable.texture.height,
                                                                          textureInfo);
        sk_sp<SkSurface> surface = SkSurfaces::WrapBackendRenderTarget(self.skiaContext,
                                                                       backendRT,
                                                                       kTopLeft_GrSurfaceOrigin,
                                                                       kBGRA_8888_SkColorType,
                                                                       nullptr,
                                                                       nullptr);
        draw_example(surface.get(), fPaint, rotation, arrColor);
        surface = nullptr;
        self.skiaContext->flushAndSubmit();
        
        id<MTLCommandBuffer> commandBuffer = [[self metalQueue] commandBuffer];
        [commandBuffer presentDrawable:nextDrawable];
        [commandBuffer commit];
        arrColor.clear();
    }
}
@end

@implementation CustomMetalView
- (instancetype)init
{
    self = [super init];
    if (self) {
        _isDirty = true;
        _colorToggle = false;
    }
    return self;
}
- (CGColorRef)getRedColor {
    return CGColorCreate(CGColorSpaceCreateDeviceRGB(), (CGFloat[]){1, 0, 0, 1});
}

- (CGColorRef)getGreenColor {
    return CGColorCreate(CGColorSpaceCreateDeviceRGB(), (CGFloat[]){0, 1, 0, 1});
}

- (CGColorRef)getBlueColor {
    return CGColorCreate(CGColorSpaceCreateDeviceRGB(), (CGFloat[]){0, 0, 1, 1});
}

- (CGColorRef)getRandomColor {
    CGFloat red = (CGFloat)arc4random() / UINT32_MAX;
    CGFloat green = (CGFloat)arc4random() / UINT32_MAX;
    CGFloat blue = (CGFloat)arc4random() / UINT32_MAX;
    return CGColorCreate(CGColorSpaceCreateDeviceRGB(), (CGFloat[]){red, green, blue, 1.0});
}

- (void)readyToDraw {
    self.isDirty = true;
}
- (void)drawSucess {
    self.isDirty = false;
}

- (void)toggle {
    self.colorToggle = !self.colorToggle;
}

@end
