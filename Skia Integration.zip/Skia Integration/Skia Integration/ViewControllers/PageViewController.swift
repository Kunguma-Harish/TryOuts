//
//  PageViewController.swift
//  Skia Integration
//
//  Created by Subramanian on 20/03/25.
//

import UIKit
import MetalKit

class PageViewController: UIPageViewController, UIPageViewControllerDelegate, UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if let vc1 = self.get3MetalVc() {
            return vc1
        }
        return nil
    }

    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if let vc2 = self.getCGVc() {
            return vc2
        }
        return nil
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.delegate = self
        self.dataSource = self
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let vc = get4MetalVc() {
            self.setViewControllers(
                [vc],
                direction: .forward,
                animated: true
            )
        }
    }
}


extension PageViewController {
    func get4MetalVc() -> ViewController? {
        if let vc = UIStoryboard(name: "Main", bundle: .main).instantiateViewController(withIdentifier: "ViewController") as? ViewController {
            return vc
        }
        return nil
    }

    func get3MetalVc() -> ViewController1? {
        if let vc1 = UIStoryboard(name: "Main", bundle: .main).instantiateViewController(withIdentifier: "ViewController1") as? ViewController1 {
            return vc1
        }
        return nil
    }

    func get1MetalVc() -> ViewController2? {
        if let vc2 = UIStoryboard(name: "Main", bundle: .main).instantiateViewController(withIdentifier: "ViewController2") as? ViewController2 {
            return vc2
        }
        return nil
    }

    func getCGVc() -> CGViewController? {
        if let vc2 = UIStoryboard(name: "Main", bundle: .main).instantiateViewController(withIdentifier: "CGViewController") as? CGViewController {
            return vc2
        }
        return nil
    }
}
