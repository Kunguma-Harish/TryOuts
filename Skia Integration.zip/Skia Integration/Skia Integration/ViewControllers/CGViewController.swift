//
//  CGViewController.swift
//  Skia Integration
//
//  Created by kunguma-14252 on 25/03/25.
//

import Foundation

class CGViewController: UIViewController {
    @IBOutlet weak var view1: CheckboardView!
    @IBOutlet weak var view2: CheckboardView!
    @IBOutlet weak var view3: CheckboardView!
    @IBOutlet weak var view4: CheckboardView!
    
    var timer: Timer!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.timer = Timer.scheduledTimer(withTimeInterval: TimeInterval(0.01), repeats: true) { _ in
            self.view1.setNeedsDisplay()
            self.view2.setNeedsDisplay()
            self.view3.setNeedsDisplay()
            self.view4.setNeedsDisplay()
        }
    }
}


class CheckboardView: UIView {
    var colors: [UIColor] = [UIColor.red, UIColor.green]
    var toggle: Bool = false
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    override func draw(_ rect: CGRect) {
        let context = UIGraphicsGetCurrentContext()
        let height: CGFloat = 4
        
        var x = 1
        while x > 0 {
            for i in stride(from: 0, to: rect.width, by: height) {
                for j in stride(from: 0, to: rect.height, by: height) {
                    var colorIndex: Int {
                        let calIndex = (Int(i / height) + Int(j / height)) % 2
                        if self.toggle {
                            return calIndex
                        }
                        return calIndex == 0 ? 1 : 0
                    }

                    let color: UIColor
                    if !colors.isEmpty {
                        color = colors[colorIndex]
                    } else {
                        color = UIColor(
                            red: CGFloat.random(in: 0...1),
                            green: CGFloat.random(in: 0...1),
                            blue: CGFloat.random(in: 0...1),
                            alpha: 1.0
                        )
                    }
                    
                    color.setFill()
                    let rectToDraw = CGRect(x: i, y: j, width: height, height: height)
                    context?.fill(rectToDraw)
                }
            }
            x -= 1
        }
        self.toggle.toggle()
    }
}
