//
//  ViewController.swift
//  Skia Integration
//
//  Created by Subramanian on 05/03/25.
//

import UIKit
import MetalKit

class ViewController: UIViewController, MTKViewDelegate {
    @IBOutlet weak var metalView: CustomMetalView!
    @IBOutlet weak var metalViewB: CustomMetalView!
    @IBOutlet weak var metalViewC: CustomMetalView!
    @IBOutlet weak var metalViewD: CustomMetalView!
    
    var metalDevice: MTLDevice!
    var metalQueue: MTLCommandQueue!
    var skiaRenderer: SkiaMetalRenderer!
    
    var cppSkiaRenderer: CppSkiaMetalRenderer!

    var timer: Timer!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Set up Metal
        metalDevice = MTLCreateSystemDefaultDevice()
        metalQueue = metalDevice.makeCommandQueue()
        
        print("Kungu swift : 📱 VC - \(metalDevice!).")

        metalView.device = metalDevice
        metalView.delegate = self
        metalView.readyToDraw()
        metalView.framebufferOnly = false
        metalView.sampleCount = 1
        
        metalViewB.device = metalDevice
        metalViewB.readyToDraw()
        metalViewB.delegate = self
        metalViewB.framebufferOnly = false
        metalViewB.sampleCount = 1

        metalViewC.device = metalDevice
        metalViewC.readyToDraw()
        metalViewC.delegate = self
        metalViewC.framebufferOnly = false
        metalViewC.sampleCount = 1
        
        metalViewD.device = metalDevice
        metalViewD.readyToDraw()
        metalViewD.delegate = self
        metalViewD.framebufferOnly = false
        metalViewD.sampleCount = 1

//         Initialize Skia Renderer
        cppSkiaRenderer = CppSkiaMetalRenderer(metalDevice, metalQueue)
        skiaRenderer = SkiaMetalRenderer(device: metalDevice, metalQueue)
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // No need to handle this for now
    }

    func draw(in view: MTKView) {
        if var cppSkiaRenderer {
            cppSkiaRenderer.drawInMTKView(view)
        }
        if let skiaRenderer {
            skiaRenderer.draw(in: view)
        }
    }

    func addTimer() {
        self.timer = Timer.scheduledTimer(withTimeInterval: TimeInterval(1), repeats: true) { _ in
            self.metalView.readyToDraw()
            self.metalViewB.readyToDraw()
            self.metalViewC.readyToDraw()
            self.metalViewD.readyToDraw()
        }
        self.timer.fire()
    }
}

class ViewController1: UIViewController, MTKViewDelegate {
    @IBOutlet weak var metalView: CustomMetalView!
    @IBOutlet weak var metalViewB: CustomMetalView!
    @IBOutlet weak var metalViewC: CustomMetalView!
    
    var metalDevice: MTLDevice!
    var metalQueue: MTLCommandQueue!
    var skiaRenderer: SkiaMetalRenderer!
    
    var cppSkiaRenderer: CppSkiaMetalRenderer!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up Metal
        metalDevice = MTLCreateSystemDefaultDevice()
        metalQueue = metalDevice.makeCommandQueue()

        print("Kungu swift 📱 VC1 - \(metalDevice!).")
        
        metalView.device = metalDevice
        metalView.readyToDraw()
        metalView.delegate = self
        metalView.framebufferOnly = false
        metalView.sampleCount = 1
        
        metalViewB.device = metalDevice
        metalViewB.readyToDraw()
        metalViewB.delegate = self
        metalViewB.framebufferOnly = false
        metalViewB.sampleCount = 1

        metalViewC.device = metalDevice
        metalViewC.readyToDraw()
        metalViewC.delegate = self
        metalViewC.framebufferOnly = false
        metalViewC.sampleCount = 1

        // Initialize Skia Renderer
        cppSkiaRenderer = CppSkiaMetalRenderer(metalDevice, metalQueue)
        skiaRenderer = SkiaMetalRenderer(device: metalDevice, metalQueue)
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // No need to handle this for now
    }

    func draw(in view: MTKView) {
        if var cppSkiaRenderer {
            cppSkiaRenderer.drawInMTKView(view)
        }
        if let skiaRenderer {
            skiaRenderer.draw(in: view)
        }
    }

    func addTimer() {
        let timer = Timer.scheduledTimer(withTimeInterval: TimeInterval(1), repeats: true) { _ in
            self.metalView.readyToDraw()
            self.metalViewB.readyToDraw()
            self.metalViewC.readyToDraw()
        }
        timer.fire()
    }
}

class ViewController2: UIViewController, MTKViewDelegate {
    @IBOutlet weak var metalView: CustomMetalView!
    
    var metalDevice: MTLDevice!
    var metalQueue: MTLCommandQueue!
    var skiaRenderer: SkiaMetalRenderer!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Set up Metal
        metalDevice = MTLCreateSystemDefaultDevice()
        metalQueue = metalDevice.makeCommandQueue()

        print("Kungu swift : 📱 VC2 - \(metalDevice!).")
        
        metalView.device = metalDevice
        metalView.readyToDraw()
        metalView.delegate = self
        metalView.framebufferOnly = false
        metalView.sampleCount = 1

        let timer = Timer.scheduledTimer(withTimeInterval: TimeInterval(1), repeats: true) { _ in
            self.metalView.readyToDraw()
        }
        timer.fire()
       
        // Initialize Skia Renderer
        skiaRenderer = SkiaMetalRenderer(device: metalDevice, metalQueue)
    }

    func mtkView(_ view: MTKView, drawableSizeWillChange size: CGSize) {
        // No need to handle this for now
    }

    func draw(in view: MTKView) {
        if let skiaRenderer {
            skiaRenderer.draw(in: view)
        }
    }
}
