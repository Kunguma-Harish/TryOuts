function Debug(msg) {
  // by leaving this blank, closure optimizes out calls (and the messages)
  // which trims down code size and marginally improves runtime speed.
}
/** @const */ var IsDebug = false;
