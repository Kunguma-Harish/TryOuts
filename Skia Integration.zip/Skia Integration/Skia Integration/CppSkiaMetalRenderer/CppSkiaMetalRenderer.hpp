//
//  CppSkiaMetalRenderer.hpp
//  Skia Integration
//
//  Created by kunguma-14252 on 01/04/25.
//

#ifndef CppSkiaMetalRenderer_hpp
#define CppSkiaMetalRenderer_hpp

#include <stdio.h>
#import <Foundation/Foundation.h>
#import <MetalKit/MetalKit.h>

#import "include/gpu/ganesh/GrDirectContext.h"
#import "include/gpu/ganesh/mtl/GrMtlBackendContext.h"
#include "include/core/SkPaint.h"

//@protocol MTLDevice;
//@protocol MTLCommandQueue;

class CppSkiaMetalRenderer {
public:
    CppSkiaMetalRenderer(id<MTLDevice> device, id<MTLCommandQueue> queue);
    void drawInMTKView(MTKView* view);

private:
    id<MTLDevice> device;
    id<MTLCommandQueue> queue;
    GrMtlBackendContext backendContext;
    sk_sp<GrDirectContext> _skiaContextHolder;
    SkPaint fPaint;
    SkPaint cusPaint;
    std::vector<CGColorRef> arrColor;
    int count = 0;
};

//class CppCustomMetalView: MTKView {
//public:
//    CppCustomMetalView();
//
//    bool isDirty;
//    bool toggleColor;
//
//    void readyToDraw();
//    void drawSucess();
//    void toggle();
//
//    CGColorRef getRedColor();
//    CGColorRef getGreenColor();
//    CGColorRef getBlueColor();
//};
#endif /* CppSkiaMetalRenderer_hpp */
